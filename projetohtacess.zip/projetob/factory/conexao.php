<?php
    $server = "localhost";
    $user = "root";
    $senha = "";
    $bdname = "dbagenda2024";
    $conn = mysqli_connect($server,$user,$senha,$bdname);
?>