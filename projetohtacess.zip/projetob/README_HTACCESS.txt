Ative o módulo mod_rewrite, necessário para regras de reescrita de URLs:

	sudo a2enmod rewrite
	sudo systemctl restart apache2

Edite o arquivo de configuração do Apache:

	sudo nano /etc/apache2/sites-available/000-default.conf

	Dentro da diretiva <VirtualHost *:80>, adicione ou modifique para incluir:
	<VirtualHost *:80>
	<Directory /var/www/html>
		AllowOverride All
		Require all granted
	</Directory>

Reinicie o Apache para aplicar as alterações:
	sudo systemctl restart apache2
