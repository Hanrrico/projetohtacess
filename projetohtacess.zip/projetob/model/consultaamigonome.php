<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/sucessoconsulta.css">
    <title>Consulta Amigo</title>
</head>
<body>
    <?php
        include_once "../factory/conexao.php";
        $nome = $_POST["cxpesquisa"];
        $consultar = "select * from tbamigos where nome = '$nome'";
        $executar = mysqli_query($conn, $consultar);

        $linha = mysqli_fetch_array($executar);
    ?>
    <form action="alteraramigo.php" method="POST">
    <div id="cxprincipal">
        <br>
<label for="">Codigo</label>
    <input type="text" name="cxcodigo" value="<?php echo $linha ['cod'] ?>"readonly />
    <br>
    <label for="">Nome:</label>
    <input type="text" name="cxnome" value="<?php echo $linha ['nome'] ?>"/>
<br>
    <label for="">E-mail:</label>
    <input type="text" name="cxemail" value="<?php echo $linha ['email'] ?>"/>
<br>
    <label for="">Data de Nascimento:</label>
    <input type="text" name="cxdatanasc" value="<?php echo $linha ['datanasc'] ?>"/>
<br>
    <label for="">Telefone:</label>
    <input type="text" name="cxtel" value="<?php echo $linha ['tel'] ?>"/>
<br>

<a href="/projetob/view/index.php" class="botao-voltar">Menu</a>
<br>
<div class="botao-voltar">
<input type="submit" value="Alterar">
</div>
<a href="deletaramigo.php?id=<?php echo $linha["cod"] ?>">Excluir</a>
</div>
</form>
</body>
</html>